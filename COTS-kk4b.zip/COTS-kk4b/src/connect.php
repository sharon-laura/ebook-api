<?php

    $server = "localhost";
    $user = "root";
    $password = "root";
    $db_name = "drugs_storage";

    $db = mysqli_connect($server, $user, $password, $db_name);

    if (!$db) {
        die("Gagal terhubung kedatabase: ". mysqli_connect_error());
    }

?>