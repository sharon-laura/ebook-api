<?php
    include("../src/fungsi.php");
    $luaspersegi = persegi(2);
    echo($luaspersegi);
    echo("</br>");
    $segitiga = segitiga(3, 4);
    echo($segitiga);
    echo("</br>");
    $persegiPanjang = persegiPanjang(8, 4);
    echo($persegiPanjang);
    echo("</br>");
    $lingkaran = lingkaran(6);
    echo($lingkaran);
?>